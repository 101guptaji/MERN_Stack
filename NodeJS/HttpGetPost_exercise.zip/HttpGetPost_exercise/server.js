/*
    Objective: Create a Node.js HTTP server that responds to GET and POST requests.
    
    Requirements:
        Create a new Node.js project using npm init.
        Create a file called server.js.
        Use the http module to create an HTTP server.
        Handle GET requests and respond with a message.
        Handle POST requests and respond with the request body.
*/
const http = require('http');
const fs = require("fs");

http.createServer((req, res) => {
    if (req.method === 'GET') {
        // reading data from file
        let data = fs.readFileSync("input.txt", "utf-8");

        // writing data to response
        res.writeHead(200, { "content-type": "text/html" })
        res.end(data);

    } 
    else if (req.method === 'POST') {
        let body = '\n';
        req.on('data', (chunk) => {
            body += chunk;
        });

        req.on('end', () => {
            // writing data to file
            fs.appendFileSync("input.txt", body);

            res.writeHead(200, { 'content-type': 'text/plain' });
            res.end(`Received: ${body}`);
        });
    }
})
.listen(8080, () => {
    console.log('Server running at http://localhost:8080');
});