// Create table heading
const tableHeading = document.createElement('tr');
tableHeading.innerHTML = `
    <tr>
        <th>Sr. No.</th>
        <th>Title</th>
        <th>Price</th>
    </tr>
    `;

const rows = [];
function submitItem(){
    let item_name = document.getElementById("item-name-input");
    let item_price = document.getElementById("item-price-input");

    if(item_name.value!=="" && item_price.value!==""){
        const newItem = {
            id : rows.length+1,
            name : item_name.value,
            price: item_price.value
        }
        //console.log(newItem);
        rows.push(newItem);

        item_name.value = "";
        item_price.value = "";

        //update table
        const table = document.getElementsByTagName("table")[0];
        table.innerHTML = "";
        table.appendChild(tableHeading);
        rows.forEach((row) => table.appendChild(createRow(row)));
        table.appendChild(calculateTotal(rows));
    }
}

function createRow(data) {
    const tableRow = document.createElement('tr');
    tableRow.innerHTML = `
        <td>${data.id}</td>
        <td data-ns-test="item-name">${data.name}</td>
        <td data-ns-test="item-price">${data.price}</td>`;
    
    return tableRow;
}

function calculateTotal(data) {
    let total = 0;
    for(let row of data){
        total += parseInt(row.price);
    }
    console.log(total);
    const totalRow = document.createElement('tr');
    totalRow.innerHTML = `
      <td colspan="2">Grand Total</td>
      <td data-ns-test="grandTotal">${total}</td>`;
  
    return totalRow;
  
  }